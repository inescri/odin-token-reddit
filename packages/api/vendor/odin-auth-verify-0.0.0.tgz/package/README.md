# odin-auth-verify

Server-side verification of [Odin Connect](https://www.npmjs.com/package/odin-connect)
logins. It checks Internet Computer delegation chains (Ed25519, secp256k1 and
canister-signature roots) and the session-key signature (Ed25519 and P-256)
that a browser produces when signing in with Odin, so a backend can confirm a
user controls the identity they claim.

## Status

Pre-release. The package is not published yet and the API is not stable.

## Verifying a login

`verifyOdinLogin` runs every check a backend needs and returns the user's
principal. The browser signs `messagePrefix + timestamp` with its Odin Connect
session key and sends the delegation chain, timestamp and signature:

```ts
// Browser (odin-connect). This package is Node-only, so build the message here;
// it is the same bytes as buildOdinLoginMessage(prefix, timestamp).
const timestamp = Date.now().toString();
const signature = await identity.sign(
  new TextEncoder().encode(`my-app-login:v1\n${timestamp}`),
);
// send { delegation: JSON.stringify(identity.getDelegation().toJSON()),
//        timestamp, signature: base64(signature) }
```

```ts
// Server
import {
  OdinLoginError,
  createMemoryReplayGuard,
  verifyOdinLogin,
} from 'odin-auth-verify';

const replayGuard = createMemoryReplayGuard(); // one process only

try {
  const { principal } = await verifyOdinLogin(body, {
    appCanisterId: process.env.APP_CANISTER_ID!,
    messagePrefix: 'my-app-login:v1\n',
    replayGuard,
  });
  // issue your own session for `principal`
} catch (error) {
  if (error instanceof OdinLoginError) {
    // reject with 401; error.code says why
  }
  throw error;
}
```

It checks, in order:

1. The timestamp is within `maxSkewMs` of the server clock (default 5 minutes).
2. No delegation in the chain has expired.
3. The chain is scoped to `appCanisterId`: at least one hop sets targets, and
   every hop that does includes the app. A delegation issued to another app is
   rejected.
4. Every signature in the chain verifies.
5. The chain's session key signed `messagePrefix + timestamp`. The prefix keeps
   a login signed for another app, or Odin's own bare-timestamp login, from
   being accepted.
6. The login has not been used before. `replayGuard.claim` runs only after all
   other checks pass, so forged requests cannot burn a real login.

`createMemoryReplayGuard` only works for a single server process. With several
instances, implement `ReplayGuard` on a shared store; `claim(key, expiresAtMs)`
must return `true` exactly once per key, e.g. Redis
`SET key 1 NX PXAT expiresAtMs` or an insert into a table with a unique key.

Rejected logins throw `OdinLoginError` with a `code`: `INVALID_INPUT`,
`TIMESTAMP_OUT_OF_WINDOW`, `DELEGATION_EXPIRED`, `NOT_SCOPED_TO_APP`,
`INVALID_DELEGATION_SIGNATURE`, `INVALID_SIGNATURE` or `REPLAYED`. Invalid
options (empty prefix, malformed canister ID) throw `TypeError`.

## Lower-level API

```ts
import {
  verifyDelegationChain,
  verifySessionKeySignature,
  verifyCanisterSignature,
  parseCanisterSigPubkey,
} from 'odin-auth-verify';
```

- `verifyDelegationChain(chain, options?)` checks every signature in a
  `DelegationChain`. The root may be Ed25519, secp256k1 (Plug) or a canister
  signature (SIWB, Internet Identity, NFID); later hops are Ed25519. It does not
  check expiration or targets, so also run `isDelegationValid`.
- `verifySessionKeySignature({ signingPubKey, signature, message })` checks the
  login-challenge signature made by an Ed25519 or P-256 session key. It throws
  on an unrecognised key type; treat a throw as a failed login.
- `verifyCanisterSignature({ rootDer, signatureBlob, message })` checks an IC
  canister signature against the IC root key.
- `parseCanisterSigPubkey(der)` extracts the canister ID and seed from a
  canister-signature public key.

Canister signatures verify against the Internet Computer mainnet root key by
default. `verifyDelegationChain` and `verifyCanisterSignature` accept a
`rootKey` option for tests and local replicas; never pass a key taken from the
request being verified.

## Requirements

Node.js 22 or later, and `@icp-sdk/core` 6.x as a peer dependency:

```sh
npm install odin-auth-verify @icp-sdk/core
```

`verifyDelegationChain` accepts a `DelegationChain` from either
`@icp-sdk/core` or the older `@dfinity/identity`.

## Development

```sh
npm install
npm run typecheck
npm test
npm run build
npm run lint:pkg
```

## Releasing

Releases use [release-it](https://github.com/release-it/release-it) and publish
from your machine:

1. Update `CHANGELOG.md` by hand and merge it to `main`.
2. On an up-to-date `main` with a clean working tree, run `npm run release`.

release-it runs the typecheck, tests, build and package lint, bumps the
version, commits `chore: release vX.Y.Z`, tags `vX.Y.Z`, pushes, and publishes
to npm. You need `npm login` as a package maintainer (npm prompts for a 2FA
code) and push access to the GitHub repo.

`"private": true` in `package.json` blocks publishing until the package is
cleared for its first release.

## Security

See [SECURITY.md](./SECURITY.md) to report a vulnerability.

## License

[Apache-2.0](./LICENSE)
